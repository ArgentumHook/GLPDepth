import os
import re
import numpy as np
import PIL
from PIL import Image
from torchvision import transforms
from imagecorruptions import corrupt

class StereoPhotoMetricDistortion(object):
    """Apply photometric distortion to image sequentially, every transformation
    is applied with a probability of 0.5. The position of random contrast is in
    second or second to last.
    1. random brightness
    2. random contrast (mode 0)
    3. convert color from BGR to HSV
    4. random saturation
    5. random hue
    6. convert color from HSV to BGR
    7. random contrast (mode 1)
    Args:
        brightness_delta (int): delta of brightness.
        contrast_range (tuple): range of contrast.
        saturation_range (tuple): range of saturation.
        hue_delta (int): delta of hue.
    """

    def __init__(self, brightness_delta=32, contrast_range=(0.5, 1.5), saturation_range=(0.5, 1.5), hue_delta=18):
        self.brightness_delta = brightness_delta
        self.contrast_lower, self.contrast_upper = contrast_range
        self.saturation_lower, self.saturation_upper = saturation_range
        self.hue_delta = hue_delta

    def convert(self, img, alpha=1, beta=0):
        """Multiple with alpha and add beat with clip."""
        img = img.astype(np.float32) * alpha + beta
        img = np.clip(img, 0, 255)
        return img.astype(np.uint8)

    def create_brightness(self, left_img, right_img):
        """Brightness distortion."""
        if np.random.randint(2):
            beta = random.uniform(-self.brightness_delta, self.brightness_delta)
            return (self.convert(left_img, beta=beta), self.convert(right_img, beta=beta))
        return (left_img, right_img)

    def contrast(self, left_img, right_img):
        """Contrast distortion."""
        if np.random.randint(2):
            alpha = random.uniform(self.contrast_lower, self.contrast_upper)
            return self.convert(left_img, alpha=alpha), self.convert(right_img, alpha=alpha)
        return left_img, right_img

    def saturation(self, left_img, right_img):
        """Saturation distortion."""
        if np.random.randint(2):
            alpha = random.uniform(self.saturation_lower,
                                     self.saturation_upper)
            left_img = mmcv.rgb2bgr(left_img)
            left_img = mmcv.bgr2hsv(left_img)
            left_img[:, :, 1] = self.convert(
                left_img[:, :, 1],
                alpha=alpha)
            left_img = mmcv.hsv2bgr(left_img)
            left_img = mmcv.bgr2rgb(left_img)
            ##----
            right_img = mmcv.rgb2bgr(right_img)
            right_img = mmcv.bgr2hsv(right_img)
            right_img[:, :, 1] = self.convert(
                right_img[:, :, 1],
                alpha=alpha)
            right_img = mmcv.hsv2bgr(right_img)
            right_img = mmcv.bgr2rgb(right_img)
        return left_img, right_img

    def hue(self, left_img, right_img):
        """Hue distortion."""
        if np.random.randint(2):
            rand_bias = np.random.randint(-self.hue_delta, self.hue_delta)
            left_img = mmcv.rgb2bgr(left_img)
            left_img = mmcv.bgr2hsv(left_img)
            left_img[:, :,
                0] = (left_img[:, :, 0].astype(int) +rand_bias) % 180
            left_img = mmcv.hsv2bgr(left_img)
            left_img = mmcv.bgr2rgb(left_img)
            #---
            right_img = mmcv.rgb2bgr(right_img)
            right_img = mmcv.bgr2hsv(right_img)
            right_img[:, :,
                0] = (right_img[:, :, 0].astype(int) +rand_bias) % 180
            right_img = mmcv.hsv2bgr(right_img)
            right_img = mmcv.bgr2rgb(right_img)
        return left_img, right_img

    def __call__(self, results):
        """Call function to perform photometric distortion on images.
        Args:
            results (dict): Result dict from loading pipeline.
        Returns:
            dict: Result dict with images distorted.
        """
        #if "left_imgs" in results.keys():
        left_imgs = results["left_imgs"]
        right_imgs = results["right_imgs"]
        left_res = []
        right_res = []
        for l_img, r_img in zip(left_imgs,right_imgs):
            l_img, r_img = self._subcall(l_img, r_img)
            left_res.append(l_img)
            right_res.append(r_img)
        results["left_imgs"] = left_res
        results["right_imgs"] = right_res
        return results

    def _subcall(self, left_img, right_img):
        #img = results['img']
        # random brightness
        left_img, right_img = self.brightness(left_img, right_img)
        

        # mode == 0 --> do random contrast first
        # mode == 1 --> do random contrast last
        mode = np.random.randint(0,2)
        if mode == 1:
            left_img, right_img = self.contrast(left_img, right_img)

        # random saturation
        left_img, right_img = self.saturation(left_img, right_img)
        # random hue
        left_img, right_img = self.hue(left_img, right_img)
        # random contrast
        if mode == 0:
            left_img, right_img = self.contrast(left_img, right_img)

        #results['img'] = img
        return left_img, right_img

    def __repr__(self):
        repr_str = self.__class__.__name__
        repr_str += (f'(brightness_delta={self.brightness_delta}, '
                     f'contrast_range=({self.contrast_lower}, '
                     f'{self.contrast_upper}), '
                     f'saturation_range=({self.saturation_lower}, '
                     f'{self.saturation_upper}), '
                     f'hue_delta={self.hue_delta})')
        return repr_str
